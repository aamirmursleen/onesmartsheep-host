MamaSign staging PDF validation test pack

Use these with https://staging.mamasign.com

01-valid-small-signature-test.pdf
- Expected: uploads/sends normally, recipient PDF opens.

02-valid-multipage-bulk-test.pdf
- Expected: bulk send works, recipient PDF opens.

03-large-over-25mb.pdf
- Expected: upload/send blocked by size validation. No recipient email should be sent.

04-corrupt-renamed.pdf
- Expected: send blocked with invalid PDF/read error. No recipient email should be sent.

05-empty.pdf
- Expected: send blocked as empty/invalid. No recipient email should be sent.
